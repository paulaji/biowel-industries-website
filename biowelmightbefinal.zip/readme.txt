Website for Biowel Industries.
Distributors of cleanliness/hygiene products focusing on four categories namely, housekeeping, disinfection, kitchen cleaning and laundry care products!